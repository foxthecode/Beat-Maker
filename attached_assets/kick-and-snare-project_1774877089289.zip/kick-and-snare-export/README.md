# Kick & Snare — Drum Sequencer v8

A browser-based drum sequencer built with React + Web Audio API.

## Features

- **Step sequencer** with 16+ steps, dynamic tracks (add/remove instruments)
- **Sample engine** — load your own WAV/MP3 samples per track, with improved synth fallback
- **Default samples** — BWJAZZ Kick + BB3 Snare Snake loaded at startup
- **Full FX chain per track** — Pitch, Filter, Drive, Crush, Compressor, Reverb (early reflections + filtered decay), Delay (with BPM sync), Volume, Pan
- **SSL-style channel strip** with vertical drag faders, section on/off bypass
- **Per-step velocity** — drag vertically on active steps (visual fill height)
- **Per-step nudge** — drag horizontally on active steps (snap 5ms)
- **Time signatures** — 4/4, 3/4, 6/8, 5/4, 7/8, 5/8 + custom (beats × subdivisions)
- **Beat groupings** for asymmetric meters (2+2+3, 3+2+2, etc.)
- **Metronome** with 3-level woodblock sound (accent/beat/subdivision) + volume drag
- **Swing** 0-100% with proper timing (steals from even steps, gives to odd)
- **Keyboard input** — AZERTY default (Q,S,D,F,G,H,J,K), configurable
- **Live recording** — REC button captures keyboard/pad hits to nearest step
- **Keyboard shortcuts** — Space=Play/Stop, Alt=Record, ←→=BPM ±1, ↑↓=BPM ±5
- **Animated stick figure drummer** in the header, synced to active hits
- **Pattern bank** — up to 8 patterns with duplicate/delete
- **Templates** — Amen Break, Funky Drummer, Boom Bap, 808 Trap, Waltz, Afrobeat 6/8
- **Light theme** (Daylight)

## Quick Start

```bash
npm install
npm run dev
```

Then open http://localhost:3000

## Build for Production

```bash
npm run build
```

Output in `dist/` folder.

## Project Structure

```
kick-and-snare/
├── index.html          # Entry HTML
├── package.json        # Dependencies
├── vite.config.js      # Vite configuration
├── src/
│   ├── main.jsx        # React mount point
│   ├── App.jsx         # Main application (sequencer, engine, UI)
│   └── defaultSamples.js  # Base64-encoded default kick & snare samples
└── README.md
```

## Architecture Notes

### Audio Engine (`Eng` class in App.jsx)
- Persistent FX chains per track (created once, parameters updated via `setTargetAtTime`)
- Lookahead scheduler (100ms ahead, 25ms check interval) for sample-accurate timing
- Convolution reverb with synthesized impulse response (early reflections + filtered decay)
- Samples decoded from base64 at init or loaded from user files

### Key Design Decisions
- All state in React hooks, audio refs in a mutable `R` object for scheduler access
- Drag system: unified `startDrag` handles click (toggle), horizontal drag (nudge), vertical drag (velocity), and double-tap (reset)
- SVG drummer animations driven by pattern data + current step

## Continuing Development

Good next steps:
- **Song arrangement** — timeline for chaining patterns with drag & drop
- **Probability per step** — % chance to trigger (humanization)
- **Ratcheting** — multiple hits per step (doubles, triplets)
- **Euclidean pattern generator**
- **Polyrhythm** — different step counts per track
- **Audio export** — bounce to WAV/MP3
- **MIDI export**
- **Freesound.org integration** — search & load samples from the web (needs API key)
- **Dark theme** option (colors defined in THEMES object)
- **Storage persistence** — save/load sessions

## License

MIT
